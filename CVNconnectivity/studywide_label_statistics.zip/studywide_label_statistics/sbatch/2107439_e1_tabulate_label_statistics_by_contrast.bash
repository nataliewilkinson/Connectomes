#!/bin/bash
echo \#
#SBATCH 
#SBATCH --reservation=rja20_4
#SBATCH  --mem 10000 
#SBATCH  -v
#SBATCH  -s 
#SBATCH  --output=/glusterspace/VBM_13colton01_chass_symmetric2_April2017analysis-work/dwi/SyN_0p5_3_0p5_fa/faMDT_nos2_n28_i6/stats_by_region/labels/post_affine_native_space/chass_symmetric2//stats//studywide_label_statistics//sbatch//slurm-%j.out 
/home/rja20/cluster_code/workstation_code/analysis/vbm_pipe/label_stats_executables/study_stats_by_contrast_executable/20170619_1151/run_study_stats_by_contrast_exec.sh /cm/shared/apps/MATLAB/R2015b/ /glusterspace/VBM_13colton01_chass_symmetric2_April2017analysis-work/dwi/SyN_0p5_3_0p5_fa/faMDT_nos2_n28_i6/stats_by_region/labels/post_affine_native_space/chass_symmetric2//stats//individual_label_statistics/ e1 N51211,N51221,N51231,N51383,N51386,N51404,N51406,N51193,N51136 /glusterspace/VBM_13colton01_chass_symmetric2_April2017analysis-work/dwi/SyN_0p5_3_0p5_fa/faMDT_nos2_n28_i6/stats_by_region/labels/post_affine_native_space/chass_symmetric2//stats//studywide_label_statistics/ 
